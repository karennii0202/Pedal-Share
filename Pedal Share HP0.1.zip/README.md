
  # ホームページ作成

  This is a code bundle for ホームページ作成. The original project is available at https://www.figma.com/design/PAeDRRTaQRigGEklZ3JHBM/%E3%83%9B%E3%83%BC%E3%83%A0%E3%83%9A%E3%83%BC%E3%82%B8%E4%BD%9C%E6%88%90.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  