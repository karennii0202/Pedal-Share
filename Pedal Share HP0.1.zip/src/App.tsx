import { useState } from 'react';
import { Header } from './components/Header';
import { TopPage } from './components/TopPage';
import { ShareServicePage } from './components/ShareServicePage';
import { SponsorsPage } from './components/SponsorsPage';
import { SponsorDetailPage } from './components/SponsorDetailPage';
import { CompanyInfoPage } from './components/CompanyInfoPage';
import { NewsPage } from './components/NewsPage';
import { ContactPage } from './components/ContactPage';
import { Footer } from './components/Footer';

export type Page = 'top' | 'share-service' | 'sponsors' | 'sponsor-detail' | 'company-info' | 'news' | 'contact';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('top');
  const [selectedSponsorId, setSelectedSponsorId] = useState<string | null>(null);

  const navigateToSponsorDetail = (sponsorId: string) => {
    setSelectedSponsorId(sponsorId);
    setCurrentPage('sponsor-detail');
    window.scrollTo(0, 0);
  };

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
    setSelectedSponsorId(null);
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header currentPage={currentPage} onNavigate={navigateTo} />
      <main className="flex-1">
        {currentPage === 'top' && <TopPage onNavigate={navigateTo} />}
        {currentPage === 'share-service' && <ShareServicePage onNavigate={navigateTo} />}
        {currentPage === 'sponsors' && <SponsorsPage onSponsorClick={navigateToSponsorDetail} />}
        {currentPage === 'sponsor-detail' && <SponsorDetailPage sponsorId={selectedSponsorId} onBack={() => navigateTo('sponsors')} />}
        {currentPage === 'company-info' && <CompanyInfoPage />}
        {currentPage === 'news' && <NewsPage />}
        {currentPage === 'contact' && <ContactPage />}
      </main>
      <Footer onNavigate={navigateTo} />
    </div>
  );
}