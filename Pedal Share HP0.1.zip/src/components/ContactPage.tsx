import { useState } from 'react';
import { Send, Mail, Phone, MapPin } from 'lucide-react';

export function ContactPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    organization: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('お問い合わせを送信しました。（デモ機能）');
  };

  return (
    <div className="pt-20">
      {/* Hero - Welcoming */}
      <section className="py-32 bg-white">
        <div className="max-w-4xl mx-auto px-8 lg:px-16 text-center">
          <h1 className="text-5xl md:text-6xl mb-8">お問い合わせ</h1>
          <p className="text-2xl text-gray-600 leading-relaxed mb-8">
            PedalShareへのご関心、ありがとうございます
          </p>
          <p className="text-lg text-gray-500 leading-relaxed">
            協賛・連携のご相談、取材のご依頼、<br />
            サービスに関するご質問など、お気軽にお問い合わせください。<br />
            若い団体ですが、真剣に取り組んでいます。
          </p>
        </div>
      </section>

      {/* Form & Contact Info */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-5xl mx-auto px-8 lg:px-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
            {/* Form */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-2xl p-10 shadow-sm">
                <form onSubmit={handleSubmit} className="space-y-8">
                  <div>
                    <label className="block text-gray-700 mb-3 text-lg">お名前 *</label>
                    <input
                      type="text"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-5 py-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-lg"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-3 text-lg">メールアドレス *</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-5 py-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-lg"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-3 text-lg">団体・企業名</label>
                    <input
                      type="text"
                      value={formData.organization}
                      onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                      className="w-full px-5 py-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-lg"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-3 text-lg">件名 *</label>
                    <input
                      type="text"
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full px-5 py-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent text-lg"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-gray-700 mb-3 text-lg">お問い合わせ内容 *</label>
                    <textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      rows={8}
                      className="w-full px-5 py-4 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent resize-none text-lg"
                      required
                    />
                  </div>

                  <div className="bg-gray-50 border border-gray-200 rounded-xl p-6">
                    <p className="text-sm text-gray-600 leading-relaxed">
                      ※ お送りいただいた個人情報は、お問い合わせへの回答以外の目的では使用いたしません。<br />
                      ※ 回答までに数日かかる場合がございます。あらかじめご了承ください。
                    </p>
                  </div>

                  <button
                    type="submit"
                    className="w-full flex items-center justify-center px-8 py-5 bg-cyan-600 text-white rounded-xl hover:bg-cyan-700 transition-colors text-lg shadow-md"
                  >
                    <Send className="mr-3 h-6 w-6" />
                    送信する
                  </button>
                </form>
              </div>
            </div>

            {/* Contact Info */}
            <div className="space-y-8">
              <div className="bg-white rounded-2xl p-8 shadow-sm">
                <h3 className="text-xl mb-6">直接のご連絡</h3>
                
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center">
                      <Mail className="h-6 w-6 text-cyan-600" />
                    </div>
                    <div>
                      <p className="text-gray-600 text-sm mb-1">メール</p>
                      <a href="mailto:info@example.com" className="text-cyan-600 hover:text-cyan-700">
                        info@example.com
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center">
                      <Phone className="h-6 w-6 text-cyan-600" />
                    </div>
                    <div>
                      <p className="text-gray-600 text-sm mb-1">電話</p>
                      <p className="text-gray-900">03-1234-5678</p>
                      <p className="text-gray-500 text-sm mt-1">平日 10:00〜17:00</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-cyan-100 rounded-lg flex items-center justify-center">
                      <MapPin className="h-6 w-6 text-cyan-600" />
                    </div>
                    <div>
                      <p className="text-gray-600 text-sm mb-1">住所</p>
                      <p className="text-gray-900">
                        徳島県徳島市川内町鈴江北６１番地の１<br />
                        レジデンス古山ビル２階
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-cyan-50 border border-cyan-200 rounded-2xl p-8">
                <h3 className="text-lg mb-3">協賛・連携について</h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  企業・団体との連携プロジェクトについては、別途詳細な提案資料をご用意しております。
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}