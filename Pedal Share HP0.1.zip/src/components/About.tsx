import { Target, Heart, Award } from 'lucide-react';

export function About() {
  return (
    <section id="about" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-gray-900 mb-4">会社概要</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            私たちは、お客様の成功を第一に考え、常に最高のサービスを提供することを目指しています。
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-xl shadow-sm">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Target className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-gray-900 mb-3">私たちのミッション</h3>
            <p className="text-gray-600">
              革新的なソリューションを通じて、お客様のビジネスに価値を提供し、
              持続可能な成長を実現します。
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-sm">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Heart className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-gray-900 mb-3">私たちの価値観</h3>
            <p className="text-gray-600">
              誠実さ、革新性、そしてお客様への献身を核として、
              常に最高品質のサービスを提供します。
            </p>
          </div>

          <div className="bg-white p-8 rounded-xl shadow-sm">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
              <Award className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-gray-900 mb-3">私たちの実績</h3>
            <p className="text-gray-600">
              数多くのプロジェクトで成功を収め、
              お客様から高い評価をいただいています。
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
