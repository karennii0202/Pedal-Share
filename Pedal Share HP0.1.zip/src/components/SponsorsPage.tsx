interface SponsorsPageProps {
  onSponsorClick: (sponsorId: string) => void;
}

export function SponsorsPage({ onSponsorClick }: SponsorsPageProps) {
  return (
    <div className="pt-20">
      {/* Hero - Minimal */}
      <section className="py-32 bg-white">
        <div className="max-w-4xl mx-auto px-8 lg:px-16 text-center">
          <h1 className="text-5xl md:text-6xl mb-8">協賛・連携</h1>
          <p className="text-2xl text-gray-600 leading-relaxed">
            準備中
          </p>
        </div>
      </section>
    </div>
  );
}