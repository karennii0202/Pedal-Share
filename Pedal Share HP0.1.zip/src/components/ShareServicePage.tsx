import { Smartphone, MapPin, Bike, CheckCircle } from 'lucide-react';
import { Page } from '../App';
import pedalShareIcon from 'figma:asset/8357ddd087472cc52e57df09b2022f1e3d0f3ab6.png';
import loginScreen from 'figma:asset/dd6dc242e8230dfc3a7bc5d12a5853dd39c29cfd.png';
import signupScreen from 'figma:asset/d5e82e32b1eb953b0936501234c3d975bd00729b.png';
import accountScreen from 'figma:asset/13ff1f7fdaa0ebc43a5dee619d18009431c91477.png';
import findPortScreen from 'figma:asset/07e6b36ceb80677dd22e4d335596bae35b886f77.png';
import unlockScreen from 'figma:asset/bcc62b3e6b3c9fc6a68ee22914b502ba753c04aa.png';
import returnScreen from 'figma:asset/d07fe766c124d7b91920d9f8ee9a8512bc5cfedb.png';

interface ShareServicePageProps {
  onNavigate: (page: Page) => void;
}

export function ShareServicePage({ onNavigate }: ShareServicePageProps) {
  return (
    <div className="pt-20">
      {/* What is PedalShare */}
      <section className="py-16 sm:py-24 md:py-32 bg-gray-50">
        <div className="max-w-5xl mx-auto px-5 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-20">
            <h2 className="mb-6 sm:mb-8">
              PedalShareとは
            </h2>
            <p className="text-gray-700 leading-relaxed max-w-3xl mx-auto">
              地方に合わせて設計された、シェアサイクルサービスです。
            </p>
          </div>

          <div className="max-w-3xl mx-auto mb-16 sm:mb-20">
            <p className="text-gray-700 leading-loose text-center">
              PedalShareは、公共交通が十分に機能していない地方で、<br />
              誰もが「行きたい場所へ行ける」選択肢を増やすためのシェアサイクルサービスです。<br /><br />
              都市部向けの大規模サービスをそのまま導入するのではなく、<br />
              地方の暮らし・使われ方に合わせて、<br />
              小さく始め、実証しながら育てることを前提に設計されています。
            </p>
          </div>

          {/* How to Use - Illustration */}
          <div className="bg-gradient-to-br from-cyan-50 to-blue-50 rounded-2xl p-8 sm:p-12">
            <h3 className="text-center mb-8 sm:mb-10">
              どうやって使うのか
            </h3>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-8 mb-6">
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full flex items-center justify-center mb-4 shadow-md">
                  <Smartphone className="w-10 h-10 sm:w-12 sm:h-12 text-cyan-600" />
                </div>
                <p className="text-center text-gray-700">アプリで<br />利用登録</p>
              </div>
              <svg className="w-6 h-6 text-cyan-600 rotate-90 sm:rotate-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full flex items-center justify-center mb-4 shadow-md">
                  <MapPin className="w-10 h-10 sm:w-12 sm:h-12 text-cyan-600" />
                </div>
                <p className="text-center text-gray-700">自転車を<br />見つける</p>
              </div>
              <svg className="w-6 h-6 text-cyan-600 rotate-90 sm:rotate-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full flex items-center justify-center mb-4 shadow-md">
                  <Bike className="w-10 h-10 sm:w-12 sm:h-12 text-cyan-600" />
                </div>
                <p className="text-center text-gray-700">解錠して<br />利用開始</p>
              </div>
            </div>
            <p className="text-center text-gray-600 leading-relaxed">
              自転車にはスマートロックを取り付けており、<br />
              必要なときに、必要な場所から、すぐに使えます。
            </p>
          </div>
        </div>
      </section>

      {/* Registration Section */}
      <section className="py-16 sm:py-24 md:py-32 bg-white">
        <div className="max-w-5xl mx-auto px-5 sm:px-6 lg:px-8">
          <h2 className="text-center mb-6 sm:mb-8">登録方法</h2>
          <p className="text-gray-600 text-center mb-12 sm:mb-20">登録は簡単</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-12">
            {/* Step 1 - Login Screen */}
            <div className="flex flex-col items-center">
              <div className="mb-6 w-64 overflow-hidden rounded-2xl shadow-2xl bg-white" style={{ height: '520px' }}>
                <img 
                  src={loginScreen} 
                  alt="ログイン画面"
                  className="w-full h-auto"
                  style={{ 
                    marginTop: '-60px'
                  }}
                />
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-10 h-10 bg-cyan-600 text-white rounded-full mb-3">
                  1
                </div>
                <h3>アプリを開く</h3>
                <p className="text-gray-600 mt-2">ログイン方法を選択</p>
              </div>
            </div>

            {/* Step 2 - Signup Screen */}
            <div className="flex flex-col items-center">
              <div className="mb-6 w-64 overflow-hidden rounded-2xl shadow-2xl bg-white" style={{ height: '520px' }}>
                <img 
                  src={signupScreen} 
                  alt="サインアップ画面"
                  className="w-full h-auto"
                  style={{ 
                    marginTop: '-60px'
                  }}
                />
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-10 h-10 bg-cyan-600 text-white rounded-full mb-3">
                  2
                </div>
                <h3>情報を入力</h3>
                <p className="text-gray-600 mt-2">表示名とメールアドレス</p>
              </div>
            </div>

            {/* Step 3 - Account Screen */}
            <div className="flex flex-col items-center">
              <div className="mb-6 w-64 overflow-hidden rounded-2xl shadow-2xl bg-white" style={{ height: '520px' }}>
                <img 
                  src={accountScreen} 
                  alt="アカウント画面"
                  className="w-full h-auto"
                  style={{ 
                    marginTop: '-60px'
                  }}
                />
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-10 h-10 bg-cyan-600 text-white rounded-full mb-3">
                  3
                </div>
                <h3>完了</h3>
                <p className="text-gray-600 mt-2">すぐに利用開始できます</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How to Use - Step by Step */}
      <section className="py-16 sm:py-24 md:py-32 bg-gray-50">
        <div className="max-w-5xl mx-auto px-5 sm:px-6 lg:px-8">
          <h2 className="text-center mb-12 sm:mb-20">使い方</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 sm:gap-12">
            {/* Step 1 - Find Port */}
            <div className="flex flex-col items-center">
              <div className="mb-6 w-64 overflow-hidden rounded-2xl shadow-2xl bg-white" style={{ height: '520px' }}>
                <img 
                  src={findPortScreen} 
                  alt="ポート検索画面"
                  className="w-full h-auto"
                />
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-10 h-10 bg-cyan-600 text-white rounded-full mb-3">
                  1
                </div>
                <h3>ポートを探す</h3>
                <p className="text-gray-600 mt-2">地域内のポートから自転車を選ぶ</p>
              </div>
            </div>

            {/* Step 2 - Unlock */}
            <div className="flex flex-col items-center">
              <div className="mb-6 w-64 overflow-hidden rounded-2xl shadow-2xl bg-white" style={{ height: '520px' }}>
                <img 
                  src={unlockScreen} 
                  alt="解錠画面"
                  className="w-full h-auto"
                />
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-10 h-10 bg-cyan-600 text-white rounded-full mb-3">
                  2
                </div>
                <h3>移動する</h3>
                <p className="text-gray-600 mt-2">好きな場所へ、自由に</p>
              </div>
            </div>

            {/* Step 3 - Return */}
            <div className="flex flex-col items-center">
              <div className="mb-6 w-64 overflow-hidden rounded-2xl shadow-2xl bg-white" style={{ height: '520px' }}>
                <img 
                  src={returnScreen} 
                  alt="返却画面"
                  className="w-full h-auto"
                />
              </div>
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-10 h-10 bg-cyan-600 text-white rounded-full mb-3">
                  3
                </div>
                <h3>返却</h3>
                <p className="text-gray-600 mt-2">どのポートでも返却OK</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing - Clean */}
      <section className="py-16 sm:py-24 md:py-32 bg-white">
        <div className="max-w-5xl mx-auto px-5 sm:px-6 lg:px-8">
          <h2 className="text-center mb-12 sm:mb-20">料金プラン</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 sm:gap-12 mb-12 sm:mb-20">
            <div className="bg-white border-2 border-gray-200 rounded-2xl p-8 sm:p-10 text-center">
              <h3 className="mb-6">一般利用</h3>
              <div className="mb-8">
                <div className="mb-2">¥120</div>
                <p className="text-gray-600">2時間</p>
              </div>
              <p className="text-gray-500">延長:1時間毎 300円</p>
            </div>

            <div className="bg-white border-2 border-cyan-600 rounded-2xl p-8 sm:p-10 text-center relative">
              <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-6 py-2 bg-cyan-600 text-white rounded-full">
                おすすめ
              </div>
              <h3 className="mb-6">定期購入</h3>
              <div className="mb-8">
                <div className="mb-2">月額 ¥700</div>
                <p className="text-gray-600">毎日12時間無料</p>
              </div>
              <p className="text-gray-500">延長:1時間毎 300円</p>
            </div>
          </div>

          {/* Student Coupon - Hero Style */}
          <div className="bg-gradient-to-br from-cyan-600 to-cyan-700 rounded-3xl p-10 sm:p-16 text-center text-white shadow-2xl mb-12 sm:mb-20">
            <div className="inline-block px-6 py-2 bg-white/20 rounded-full mb-6">
              学生限定特典
            </div>
            <h3 className="mb-6 leading-tight">
              毎日12時間<br />無料クーポン配布
            </h3>
            <p className="text-cyan-100">※学生証を登録した人のみ</p>
          </div>

          {/* Enterprise Plan */}
          <div className="bg-white border-2 border-gray-900 rounded-2xl p-8 sm:p-12">
            <div className="text-center mb-8">
              <h3 className="mb-4">企業・行政向けプラン</h3>
              <p className="text-gray-600 leading-relaxed">
                実証実験、地域連携プロジェクトなど、Pedal Shareを導入してみたい方々へ
              </p>
            </div>
            <div className="text-center">
              <button 
                onClick={() => onNavigate('contact')}
                className="inline-block px-10 py-4 bg-gray-900 text-white rounded-full hover:bg-gray-800 transition-colors"
              >
                詳しく相談する
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Simple CTA */}
      <section className="py-16 sm:py-20 md:py-24 bg-gray-50">
        <div className="max-w-4xl mx-auto px-5 sm:px-6 text-center">
          <h2 className="mb-10 sm:mb-12">アプリをダウンロード</h2>
          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <img src={pedalShareIcon} alt="PedalShare App" className="h-20 w-20 sm:h-24 sm:w-24 rounded-3xl shadow-xl" />
            <div className="flex flex-col sm:flex-row gap-4">
              <button className="px-10 py-4 bg-cyan-600 text-white rounded-full hover:bg-cyan-700 transition-colors">
                App Store
              </button>
              <button className="px-10 py-4 bg-cyan-600 text-white rounded-full hover:bg-cyan-700 transition-colors">
                Google Play
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}