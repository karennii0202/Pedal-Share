import { Page } from '../App';

interface FooterProps {
  onNavigate: (page: Page) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="text-white mb-4">Colors</div>
            <p className="text-gray-400 text-sm">
              学生の青春を彩る
            </p>
          </div>

          <div>
            <h3 className="text-white mb-4">サービス</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => onNavigate('share-service')} className="hover:text-cyan-400 transition-colors">
                  PedalShare
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('news')} className="hover:text-cyan-400 transition-colors">
                  活動紹介
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('sponsors')} className="hover:text-cyan-400 transition-colors">
                  協賛・連携
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white mb-4">団体について</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => onNavigate('company-info')} className="hover:text-cyan-400 transition-colors">
                  団体概要
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('top')} className="hover:text-cyan-400 transition-colors">
                  私たちについて
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('news')} className="hover:text-cyan-400 transition-colors">
                  お知らせ
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white mb-4">お問い合わせ</h3>
            <ul className="space-y-2 text-sm">
              <li>Email: akari.matsuda@colors-youth.or.jp</li>
              <li>Tel: 090-9452-0731</li>
              <li>〒徳島県徳島市川内町鈴江北６１番地の１</li>
              <li>レジデンス古山ビル２階</li>
              <li className="pt-2">
                <button 
                  onClick={() => onNavigate('contact')} 
                  className="text-cyan-400 hover:text-cyan-300 transition-colors"
                >
                  お問い合わせフォーム →
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-gray-800">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              &copy; 2025 NPO法人 Colors / 株式会社 PedalShare. All rights reserved.
            </p>
            <div className="flex gap-6 text-sm">
              <a href="#" className="hover:text-cyan-400 transition-colors">プライバシーポリシー</a>
              <a href="#" className="hover:text-cyan-400 transition-colors">利用規約</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}