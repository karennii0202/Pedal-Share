import { Zap, Shield, Users, TrendingUp } from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: '高速パフォーマンス',
    description: '最新技術を活用し、高速で効率的なソリューションを提供します。'
  },
  {
    icon: Shield,
    title: '安心のセキュリティ',
    description: '厳重なセキュリティ対策で、大切なデータを保護します。'
  },
  {
    icon: Users,
    title: '充実したサポート',
    description: '専門スタッフが24時間365日、お客様をサポートします。'
  },
  {
    icon: TrendingUp,
    title: '成長を加速',
    description: 'ビジネスの成長を加速させる、革新的な機能を提供します。'
  }
];

export function Features() {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-gray-900 mb-4">私たちの特徴</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            お客様のビジネスを成功に導く、4つの強み
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="p-6 rounded-xl border border-gray-200 hover:border-blue-300 hover:shadow-lg transition-all"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <Icon className="h-6 w-6 text-blue-600" />
                </div>
                <h3 className="text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
