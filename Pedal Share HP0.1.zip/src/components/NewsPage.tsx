import { Calendar } from 'lucide-react';
import newsImage1 from 'figma:asset/223e869431b5154a989c6fbb3743e86bcd9896fd.png';

// Mock news data
const newsItems = [
  {
    id: 1,
    date: '2025.11.08',
    category: '活動報告',
    organization: 'NPO法人',
    title: 'にし阿波の花火の学生ボランティアの運営を行いました',
    image: newsImage1,
    excerpt: '約4か月間、学生ボランティアの募集や事前ミーティングなどを行い約70名の方々と、にし阿波の花火を支えることができました。ご協力ありがとうございました。'
  },
];

export function NewsPage() {
  return (
    <div className="pt-20">
      {/* Hero - Simple */}
      <section className="py-32 bg-white">
        <div className="max-w-4xl mx-auto px-8 lg:px-16 text-center">
          <h1 className="text-5xl md:text-6xl mb-8">お知らせ・活動紹介</h1>
        </div>
      </section>

      {/* News List - Visual Log */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-5xl mx-auto px-8 lg:px-16">
          <div className="space-y-12">
            {newsItems.map((item) => (
              <article
                key={item.id}
                className="bg-white rounded-2xl overflow-hidden hover:shadow-lg transition-shadow"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  <div className="bg-gray-200 aspect-[4/3] md:aspect-auto flex items-center justify-center">
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <p className="text-gray-400">写真</p>
                    )}
                  </div>
                  
                  <div className="md:col-span-2 p-8 md:py-8 md:pr-8 md:pl-0">
                    <div className="flex items-center gap-4 mb-4 flex-wrap">
                      <div className="flex items-center text-gray-500">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span className="text-sm">{item.date}</span>
                      </div>
                      <span className="px-4 py-1 bg-gray-100 text-gray-600 rounded-full text-sm">
                        {item.category}
                      </span>
                      <span className={`px-4 py-1 rounded-full text-sm ${
                        item.organization === 'NPO Colors' 
                          ? 'bg-blue-100 text-blue-700' 
                          : 'bg-orange-100 text-orange-700'
                      }`}>
                        {item.organization}
                      </span>
                    </div>
                    
                    <h3 className="text-2xl mb-3 hover:text-cyan-600 transition-colors cursor-pointer">
                      {item.title}
                    </h3>
                    
                    <p className="text-gray-600 leading-relaxed">
                      {item.excerpt}
                    </p>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}