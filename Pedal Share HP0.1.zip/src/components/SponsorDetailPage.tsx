import { ArrowLeft, ExternalLink } from 'lucide-react';

interface SponsorDetailPageProps {
  sponsorId: string | null;
  onBack: () => void;
}

// Mock detailed sponsor data
const sponsorDetails: Record<string, any> = {
  'sponsor-1': {
    name: '株式会社サンプル商事',
    category: '製造業',
    description: '地域密着型の製造業として、環境に配慮したものづくりを推進しています。',
    fullDescription: '1985年の創業以来、地域に根ざした製造業として成長してまいりました。環境に配慮した製品づくりと、持続可能な生産体制の構築に注力し、ISO14001を取得。地域の雇用創出にも貢献しています。',
    supportContent: '当団体のシェアサイクル事業において、自転車部品の提供および定期メンテナンスのサポートをいただいています。また、環境保全活動にも積極的にご参加いただき、地域清掃活動などにも社員の皆様と共に取り組んでいます。',
    website: 'https://example.com',
    established: '1985年',
    address: '東京都○○区○○1-2-3'
  },
  'sponsor-2': {
    name: 'グリーンエナジー株式会社',
    category: 'エネルギー',
    description: '再生可能エネルギーの普及を通じて、持続可能な社会づくりに貢献します。',
    fullDescription: '太陽光発電、風力発電などの再生可能エネルギー事業を展開。カーボンニュートラル社会の実現を目指し、クリーンエネルギーの普及に努めています。',
    supportContent: 'シェアサイクルステーションへの太陽光発電システムの提供、および環境教育プログラムへの協力をいただいています。',
    website: 'https://example.com',
    established: '2010年',
    address: '東京都△△区△△2-3-4'
  }
};

export function SponsorDetailPage({ sponsorId, onBack }: SponsorDetailPageProps) {
  if (!sponsorId || !sponsorDetails[sponsorId]) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600 mb-4">協賛企業が見つかりません</p>
          <button
            onClick={onBack}
            className="text-orange-600 hover:text-orange-700"
          >
            協賛企業一覧に戻る
          </button>
        </div>
      </div>
    );
  }

  const sponsor = sponsorDetails[sponsorId];

  return (
    <div className="pt-20">
      {/* Back Button */}
      <div className="bg-gray-50 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={onBack}
            className="inline-flex items-center text-gray-600 hover:text-cyan-600 transition-colors"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            協賛企業一覧に戻る
          </button>
        </div>
      </div>

      {/* Header */}
      <section className="py-12 bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
              <div className="bg-gray-100 rounded-lg h-64 flex items-center justify-center">
                <p className="text-gray-400">企業ロゴ</p>
              </div>
            </div>
            <div className="lg:col-span-2">
              <div className="mb-3">
                <span className="inline-block px-3 py-1 bg-cyan-100 text-cyan-600 rounded-full">
                  {sponsor.category}
                </span>
              </div>
              <h1 className="text-gray-900 mb-4">{sponsor.name}</h1>
              <p className="text-gray-600 mb-6">{sponsor.description}</p>
              <div className="space-y-2 text-gray-600">
                <p><strong>設立：</strong>{sponsor.established}</p>
                <p><strong>所在地：</strong>{sponsor.address}</p>
                {sponsor.website && (
                  <a
                    href={sponsor.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-orange-600 hover:text-orange-700"
                  >
                    公式ウェブサイト
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-12">
            <div>
              <h2 className="text-gray-900 mb-6">{sponsor.projectName}</h2>
              <p className="text-gray-600 leading-relaxed whitespace-pre-line">
                {sponsor.projectDescription}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Related Images */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-gray-900 mb-8 text-center">プロジェクトの様子</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-200 rounded-lg h-64 flex items-center justify-center">
              <p className="text-gray-500">写真を配置</p>
            </div>
            <div className="bg-gray-200 rounded-lg h-64 flex items-center justify-center">
              <p className="text-gray-500">写真を配置</p>
            </div>
            <div className="bg-gray-200 rounded-lg h-64 flex items-center justify-center">
              <p className="text-gray-500">写真を配置</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}