import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { Page } from '../App';
import logo from 'figma:asset/0319543bb701fcdda2bda01f6a362a577491f6cc.png';
import pedalShareIcon from 'figma:asset/8357ddd087472cc52e57df09b2022f1e3d0f3ab6.png';

interface HeaderProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleNavigate = (page: Page) => {
    onNavigate(page);
    setIsMenuOpen(false);
  };

  const isActive = (page: Page) => currentPage === page;

  return (
    <header className="fixed top-0 left-0 right-0 bg-white z-50 shadow-sm border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <button 
            onClick={() => handleNavigate('top')}
            className="flex-shrink-0 flex items-center gap-3"
          >
            <img src={logo} alt="Colors" className="h-12 w-auto" style={{ mixBlendMode: 'multiply' }} />
            <div className="h-10 w-px bg-gray-300"></div>
            <img src={pedalShareIcon} alt="PedalShare" className="h-10 w-10 rounded-xl" />
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => handleNavigate('top')} 
              className={`transition-colors ${isActive('top') ? 'text-cyan-600' : 'text-gray-700 hover:text-cyan-600'}`}
            >
              トップ
            </button>
            <button 
              onClick={() => handleNavigate('share-service')} 
              className={`transition-colors ${isActive('share-service') ? 'text-cyan-600' : 'text-gray-700 hover:text-cyan-600'}`}
            >
              PedalShareとは
            </button>
            <button 
              onClick={() => handleNavigate('sponsors')} 
              className={`transition-colors ${isActive('sponsors') || isActive('sponsor-detail') ? 'text-cyan-600' : 'text-gray-700 hover:text-cyan-600'}`}
            >
              協賛・連携
            </button>
            <button 
              onClick={() => handleNavigate('company-info')} 
              className={`transition-colors ${isActive('company-info') ? 'text-cyan-600' : 'text-gray-700 hover:text-cyan-600'}`}
            >
              団体概要
            </button>
            <button 
              onClick={() => handleNavigate('news')} 
              className={`transition-colors ${isActive('news') ? 'text-cyan-600' : 'text-gray-700 hover:text-cyan-600'}`}
            >
              お知らせ
            </button>
            <button 
              onClick={() => handleNavigate('contact')} 
              className="px-6 py-2 bg-gradient-to-r from-cyan-500 to-cyan-600 text-white rounded-full hover:from-cyan-600 hover:to-cyan-700 transition-all shadow-md hover:shadow-lg"
            >
              お問い合わせ
            </button>
          </nav>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-md text-gray-700 hover:bg-gray-100"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-4 space-y-2 border-t border-gray-100">
            <button
              onClick={() => handleNavigate('top')}
              className={`block w-full text-left px-4 py-2 rounded transition-colors ${isActive('top') ? 'bg-cyan-50 text-cyan-600' : 'text-gray-700 hover:bg-gray-50'}`}
            >
              トップ
            </button>
            <button
              onClick={() => handleNavigate('share-service')}
              className={`block w-full text-left px-4 py-2 rounded transition-colors ${isActive('share-service') ? 'bg-cyan-50 text-cyan-600' : 'text-gray-700 hover:bg-gray-50'}`}
            >
              PedalShareとは
            </button>
            <button
              onClick={() => handleNavigate('sponsors')}
              className={`block w-full text-left px-4 py-2 rounded transition-colors ${isActive('sponsors') || isActive('sponsor-detail') ? 'bg-cyan-50 text-cyan-600' : 'text-gray-700 hover:bg-gray-50'}`}
            >
              協賛・連携
            </button>
            <button
              onClick={() => handleNavigate('company-info')}
              className={`block w-full text-left px-4 py-2 rounded transition-colors ${isActive('company-info') ? 'bg-cyan-50 text-cyan-600' : 'text-gray-700 hover:bg-gray-50'}`}
            >
              団体概要
            </button>
            <button
              onClick={() => handleNavigate('news')}
              className={`block w-full text-left px-4 py-2 rounded transition-colors ${isActive('news') ? 'bg-cyan-50 text-cyan-600' : 'text-gray-700 hover:bg-gray-50'}`}
            >
              お知らせ
            </button>
            <button
              onClick={() => handleNavigate('contact')}
              className="block w-full text-left px-4 py-2 bg-gradient-to-r from-cyan-500 to-cyan-600 text-white rounded hover:from-cyan-600 hover:to-cyan-700 transition-all"
            >
              お問い合わせ
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}