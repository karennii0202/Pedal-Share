export function CompanyInfoPage() {
  return (
    <div className="pt-20">
      {/* Hero - Simple */}
      <section className="py-32 bg-white">
        <div className="max-w-4xl mx-auto px-8 lg:px-16 text-center">
          <h1 className="text-5xl md:text-6xl mb-8">
            団体概要
          </h1>
          <p className="text-2xl text-gray-600 leading-relaxed">
            社会性と事業性、両輪で取り組む
          </p>
        </div>
      </section>

      {/* Two Organizations - Equal Weight */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-5xl mx-auto px-8 lg:px-16">
          <div className="max-w-2xl mx-auto">
            {/* NPO */}
            <div className="bg-white rounded-2xl p-10 shadow-sm">
              <div className="inline-block px-5 py-2 bg-cyan-100 text-cyan-700 rounded-lg mb-8 text-lg">
                NPO法人
              </div>

              <h2 className="text-3xl mb-8">NPO法人 Colors</h2>

              <div className="space-y-6 text-lg">
                <div>
                  <p className="text-gray-500 mb-2">名称</p>
                  <p className="text-gray-900">NPO法人Colors</p>
                </div>

                <div>
                  <p className="text-gray-500 mb-2">本部</p>
                  <p className="text-gray-900 leading-relaxed">
                    徳島県徳島市川内町鈴江北６１番地の１
                    <br />
                    レジデンス古山ビル２階
                  </p>
                </div>

                <div>
                  <p className="text-gray-500 mb-2">設立</p>
                  <p className="text-gray-900">2024年3月27日</p>
                </div>

                <div>
                  <p className="text-gray-500 mb-2">役員</p>
                  <p className="text-gray-900 leading-relaxed">
                    代表理事　松田　明香里
                    <br />
                    副理事　　新居　果怜
                    <br />
                    監事　　　藤川　修誌
                  </p>
                </div>

                <div>
                  <p className="text-gray-500 mb-2">関連団体</p>
                  <p className="text-gray-900">
                    公益財団法人 キリン福祉財団 様
                  </p>
                </div>

                <div>
                  <p className="text-gray-500 mb-2">
                    内閣府NPOホームページ
                  </p>
                  <p className="text-gray-900">
                    <a
                      href="https://www.npo-homepage.go.jp/npoportal/detail/036000434"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-600 hover:text-cyan-700 underline"
                    >
                      詳細を見る
                    </a>
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Explanation Note */}
          <div className="mt-12 bg-white border border-gray-200 rounded-2xl p-8 text-center">
            <p className="text-gray-600 leading-relaxed text-lg">
              社会性（NPO法人）と事業性（株式会社）の二法人体制により、
              <br />
              持続可能な社会課題解決を目指しています。
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}