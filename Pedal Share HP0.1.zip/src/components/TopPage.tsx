import { Page } from '../App';
import bikeStudents1 from 'figma:asset/81d61a30c56356ed96e8af725df255ffa081736b.png';
import bikeStudents2 from 'figma:asset/1859f280a6c3d7c1a71edcc5bc005649d74690c3.png';
import newsImage1 from 'figma:asset/223e869431b5154a989c6fbb3743e86bcd9896fd.png';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Smartphone, DollarSign, MapPin, BarChart3, ArrowRight, Users, Building2, TrendingUp } from 'lucide-react';

interface TopPageProps {
  onNavigate: (page: Page) => void;
}

export function TopPage({ onNavigate }: TopPageProps) {
  return (
    <div className="pt-20">
      {/* Hero Section - Full Width Video */}
      <section className="relative min-h-[400px] sm:min-h-[600px] sm:max-h-[900px] sm:h-screen bg-gray-900 overflow-hidden">
        {/* Background Video */}
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
        >
          <source src="https://res.cloudinary.com/dxo7cvnza/video/upload/HP用の動画_hfoavl.mp4" type="video/mp4" />
        </video>
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/40 to-black/60 z-10" />
        
        {/* Hero Text */}
        <div className="absolute inset-0 z-20 flex items-center justify-center text-center px-5 sm:px-6">
          <div className="max-w-5xl">
            <h1 className="text-white mb-6 sm:mb-10 tracking-wide px-2">
              今日、どこでも行けるって、最高だ。
            </h1>
            <p className="text-white/95 leading-relaxed max-w-3xl mx-auto px-2">
              公共交通が乏しい地方で、「行けない」を理由に、<br />
              やりたいことを諦めなくていい社会をつくる。
            </p>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 sm:py-24 md:py-32 bg-white">
        <div className="max-w-4xl mx-auto px-5 sm:px-6 lg:px-8">
          <p className="leading-loose text-gray-700 text-center max-w-3xl mx-auto">
            PedalShareは、徳島をはじめとした地方で、<br className="hidden sm:inline" />
            移動を起点に、人・学生・行政・企業がつながる仕組みを<br className="hidden sm:inline" />
            実証実験からつくるプロジェクトです。
          </p>
        </div>
      </section>

      {/* Why We Do This */}
      <section className="py-16 sm:py-24 md:py-32 bg-gray-50">
        <div className="max-w-5xl mx-auto px-5 sm:px-6 lg:px-8">
          <h2 className="text-center mb-12 sm:mb-20">
            なぜ、私たちはこれをやっているのか
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 md:gap-16 items-center mb-12 sm:mb-16">
            <div className="order-2 lg:order-1">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1732045726992-70b81bb98d70?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydXJhbCUyMHRvd24lMjBidXMlMjBzdG9wfGVufDF8fHx8MTc2NjQyNjMyNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="地方の移動課題"
                className="w-full h-[250px] sm:h-[350px] md:h-[400px] object-cover rounded-lg"
              />
            </div>
            <div className="order-1 lg:order-2">
              <h3 className="mb-6 sm:mb-8">
                地方には、まだ「行けない」が多すぎる。
              </h3>
              <div className="space-y-5 sm:space-y-6 text-gray-700 leading-relaxed">
                <p>地方では、</p>
                <ul className="space-y-3 sm:space-y-4 pl-5">
                  <li className="relative before:content-['•'] before:absolute before:-left-5 before:text-gray-400">
                    バスの本数が少ない
                  </li>
                  <li className="relative before:content-['•'] before:absolute before:-left-5 before:text-gray-400">
                    夜は移動手段がなくなる
                  </li>
                  <li className="relative before:content-['•'] before:absolute before:-left-5 before:text-gray-400">
                    車がないと行動範囲が極端に狭まる
                  </li>
                </ul>
                <p>
                  そんな理由で、本当は行きたい場所、会いたい人、挑戦したい機会が、最初から選択肢から消えてしまうことがあります。
                </p>
              </div>
            </div>
          </div>

          <div className="max-w-3xl mx-auto text-center space-y-6 sm:space-y-8">
            <p className="text-gray-900 leading-loose">
              PedalShareは、<br className="sm:hidden" />
              この「行けない」を当たり前にしないために生まれました。
            </p>
          </div>
        </div>
      </section>

      {/* What is PedalShare */}
      <section className="py-16 sm:py-24 md:py-32 bg-white">
        <div className="max-w-5xl mx-auto px-5 sm:px-6 lg:px-8">
          <div className="text-center mb-12 sm:mb-20">
            <h2 className="mb-6 sm:mb-8">
              PedalShareとは
            </h2>
            <p className="text-gray-700 leading-relaxed max-w-3xl mx-auto">
              地方に合わせて設計された、シェアサイクルサービスです。
            </p>
          </div>

          <div className="max-w-3xl mx-auto mb-16 sm:mb-24">
            <p className="text-gray-700 leading-loose text-center mb-8 sm:mb-12">
              PedalShareは、公共交通が十分に機能していない地方で、<br />
              誰もが「行きたい場所へ行ける」選択肢を増やすためのシェアサイクルサービスです。<br /><br />
              都市部向けの大規模サービスをそのまま導入するのではなく、<br />
              地方の暮らし・使われ方に合わせて、<br />
              小さく始め、実証しながら育てることを前提に設計されています。
            </p>

            {/* How to Use - Illustration */}
            <div className="bg-gradient-to-br from-cyan-50 to-blue-50 rounded-2xl p-8 sm:p-12">
              <h3 className="text-center mb-8 sm:mb-10">
                どうやって使うのか
              </h3>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-8 mb-6">
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full flex items-center justify-center mb-4 shadow-md">
                    <Smartphone className="w-10 h-10 sm:w-12 sm:h-12 text-cyan-600" />
                  </div>
                  <p className="text-center text-gray-700">アプリで<br />利用登録</p>
                </div>
                <ArrowRight className="w-6 h-6 text-cyan-600 rotate-90 sm:rotate-0" />
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full flex items-center justify-center mb-4 shadow-md">
                    <MapPin className="w-10 h-10 sm:w-12 sm:h-12 text-cyan-600" />
                  </div>
                  <p className="text-center text-gray-700">自転車を<br />見つける</p>
                </div>
                <ArrowRight className="w-6 h-6 text-cyan-600 rotate-90 sm:rotate-0" />
                <div className="flex flex-col items-center">
                  <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full flex items-center justify-center mb-4 shadow-md">
                    <TrendingUp className="w-10 h-10 sm:w-12 sm:h-12 text-cyan-600" />
                  </div>
                  <p className="text-center text-gray-700">解錠して<br />利用開始</p>
                </div>
              </div>
              <p className="text-center text-gray-600 leading-relaxed">
                自転車にはスマートロックを取り付けており、<br />
                鍵の受け渡しや窓口対応は不要です。<br />
                必要なときに、必要な場所から、すぐに使えます。
              </p>
            </div>
          </div>

          {/* PedalShare Features */}
          <h3 className="text-center mb-10 sm:mb-14">
            PedalShareの特徴
          </h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8 mb-16 sm:mb-20">
            <div className="bg-gray-50 rounded-xl p-6 sm:p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 bg-cyan-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <DollarSign className="w-6 h-6 text-cyan-600" />
                </div>
                <div>
                  <h4 className="mb-3">
                    小規模・低コストから始められる
                  </h4>
                  <p className="text-gray-600 leading-relaxed">
                    自転車とスマートロックがあれば導入でき、大がかりな設備工事を必要としません。そのため、実証実験として柔軟な設置・移動が可能です。
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-6 sm:p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 bg-cyan-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-cyan-600" />
                </div>
                <div>
                  <h4 className="mb-3">
                    ポートを固定しすぎない設計
                  </h4>
                  <p className="text-gray-600 leading-relaxed">
                    最初から大量のポートを設置するのではなく、実証を通じて「使われる場所」を見極めながら、少しずつ配置を最適化していきます。
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-6 sm:p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 bg-cyan-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Users className="w-6 h-6 text-cyan-600" />
                </div>
                <div>
                  <h4 className="mb-3">
                    学生・地域住民が使いやすい仕組み
                  </h4>
                  <p className="text-gray-600 leading-relaxed">
                    短距離・日常利用を想定し、「たまに使いたい」人でも使いやすい設計を重視しています。（料金・運用は実証内容により調整）
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-6 sm:p-8">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 bg-cyan-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <BarChart3 className="w-6 h-6 text-cyan-600" />
                </div>
                <div>
                  <h4 className="mb-3">
                    実証から、次につなげるサービス
                  </h4>
                  <p className="text-gray-600 leading-relaxed">
                    データを集めること自体を目的にしていません。「次に、どこにポートを増やせば、より多くの人が使えるか」その判断材料を得るために実証を行っています。
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Value Proposition */}
          <div className="bg-gradient-to-br from-gray-50 to-cyan-50 rounded-2xl p-8 sm:p-12">
            <h3 className="text-center mb-10 sm:mb-12">
              PedalShareが生み出す価値
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 sm:gap-12 max-w-4xl mx-auto">
              <div>
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 bg-cyan-600 rounded-full flex items-center justify-center">
                    <Users className="w-5 h-5 text-white" />
                  </div>
                  <h4>利用者にとって</h4>
                </div>
                <ul className="space-y-3 text-gray-700 leading-relaxed">
                  <li className="flex items-start">
                    <span className="mr-3 text-cyan-600 mt-1">•</span>
                    <span>行動範囲が広がる</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-3 text-cyan-600 mt-1">•</span>
                    <span>車がなくても選択肢が増える</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-3 text-cyan-600 mt-1">•</span>
                    <span>「行けない」を理由に諦めなくてよくなる</span>
                  </li>
                </ul>
              </div>

              <div>
                <div className="flex items-center gap-3 mb-5">
                  <div className="w-10 h-10 bg-cyan-600 rounded-full flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-white" />
                  </div>
                  <h4>地域・行政・企業にとって</h4>
                </div>
                <ul className="space-y-3 text-gray-700 leading-relaxed">
                  <li className="flex items-start">
                    <span className="mr-3 text-cyan-600 mt-1">•</span>
                    <span>実際の移動実態をもとに検討できる</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-3 text-cyan-600 mt-1">•</span>
                    <span>小さな実証から始められる</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-3 text-cyan-600 mt-1">•</span>
                    <span>学生や若者との新しい接点が生まれる</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-10 sm:mt-12 pt-8 sm:pt-10 border-t border-cyan-200">
              <p className="text-center text-gray-900 leading-loose">
                移動は、ゴールではありません。
              </p>
              <p className="text-center text-gray-700 leading-loose mt-4">
                PedalShareにとって移動は、<br />
                人が動き、出会い、関係が生まれるための入口です。<br /><br />
                このサービスを通して、<br />
                地方での新しい流れと、次の選択肢をつくっていきます。
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Us, Not Big Companies */}
      <section className="py-16 sm:py-24 md:py-32 bg-gray-50">
        <div className="max-w-5xl mx-auto px-5 sm:px-6 lg:px-8">
          <h2 className="text-center mb-12 sm:mb-16">
            なぜ、大手ではなく、私たちがやるのか
          </h2>
          
          <div className="max-w-3xl mx-auto mb-12 sm:mb-16">
            <h3 className="mb-6 sm:mb-8 text-center">
              大手が来ない場所にこそ、意味がある。
            </h3>
            <div className="space-y-5 sm:space-y-6 text-gray-700 leading-relaxed">
              <p>
                都市部では、マイクロモビリティやシェアサイクルがすでに普及しています。<br />
                一方で、徳島のような地方には、大規模サービスは、ほとんど進出していません。
              </p>
              <p>それは、</p>
              <ul className="space-y-3 sm:space-y-4 pl-5">
                <li className="relative before:content-['•'] before:absolute before:-left-5 before:text-gray-400">
                  需要密度が低い
                </li>
                <li className="relative before:content-['•'] before:absolute before:-left-5 before:text-gray-400">
                  初期投資に対して赤字になりやすい
                </li>
                <li className="relative before:content-['•'] before:absolute before:-left-5 before:text-gray-400">
                  行政や地域との調整コストが高い
                </li>
              </ul>
              <p>といった「できない理由」があるからです。</p>
            </div>
          </div>

          <div className="max-w-3xl mx-auto text-center space-y-6 sm:space-y-8">
            <p className="text-gray-900 leading-loose">
              だからこそ、私たちがやる意味があります。
            </p>
            <p className="text-gray-700 leading-loose">
              PedalShareは、<br />
              短期的な黒字やスケールを目的にした「進出」ではなく、<br />
              地域と一緒に考え、試し、定着させることを前提にしています。
            </p>
          </div>
        </div>
      </section>

      {/* Our Vision */}
      <section className="py-16 sm:py-24 md:py-32 bg-white">
        <div className="max-w-5xl mx-auto px-5 sm:px-6 lg:px-8">
          <h2 className="text-center mb-12 sm:mb-20">
            私たちが目指している未来
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 md:gap-16 items-center">
            <div>
              <h3 className="mb-6 sm:mb-8">
                移動の社で、終わるつもりはありません。
              </h3>
              <div className="space-y-5 sm:space-y-6 text-gray-700 leading-relaxed">
                <p>
                  将来的には、県庁の一室や、ひとつのデスクでも構いません。
                </p>
                <p>そこにPedalShareが常にいて、</p>
                <ul className="space-y-3 sm:space-y-4 pl-5">
                  <li className="relative before:content-['•'] before:absolute before:-left-5 before:text-gray-400">
                    学生がふらっと立ち寄り
                  </li>
                  <li className="relative before:content-['•'] before:absolute before:-left-5 before:text-gray-400">
                    行政や企業と話が生まれ
                  </li>
                  <li className="relative before:content-['•'] before:absolute before:-left-5 before:text-gray-400">
                    新しい実証や挑戦が始まる
                  </li>
                </ul>
                <p>
                  そんな「地方と若者をつなぐ入口」になることを目指しています。
                </p>
                <p className="text-gray-900">
                  移動は、そのための最初のきっかけです。
                </p>
              </div>
            </div>
            <div>
              <img 
                src={newsImage1} 
                alt="学生の協働" 
                className="w-full rounded-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Current Activities */}
      <section className="py-16 sm:py-24 md:py-32 bg-gray-50">
        <div className="max-w-4xl mx-auto px-5 sm:px-6 lg:px-8">
          <h2 className="text-center mb-12 sm:mb-16">
            今、やっていること
          </h2>
          
          <div className="text-center mb-12 sm:mb-16">
            <h3 className="mb-6 sm:mb-8">
              まずは、徳島から。
            </h3>
            <div className="inline-block">
              <ul className="space-y-4 sm:space-y-5 text-left text-gray-700 leading-relaxed">
                <li className="flex items-start">
                  <span className="mr-3 text-cyan-600 mt-1">•</span>
                  <span>徳島県内での実証実験</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-3 text-cyan-600 mt-1">•</span>
                  <span>行政・企業と連携したPoCの実施</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-3 text-cyan-600 mt-1">•</span>
                  <span>学生主体による運営・検証</span>
                </li>
                <li className="flex items-start">
                  <span className="mr-3 text-cyan-600 mt-1">•</span>
                  <span>次のポート配置や展開につながる検討</span>
                </li>
              </ul>
            </div>
          </div>

          <div className="max-w-3xl mx-auto">
            <img 
              src={bikeStudents2} 
              alt="実証実験の様子" 
              className="w-full h-[250px] sm:h-[350px] md:h-[400px] object-cover rounded-lg mb-8 sm:mb-12"
            />
            <div className="text-center space-y-5 sm:space-y-6 text-gray-700 leading-loose">
              <p>
                PedalShareは、まだ完成したサービスではありません。<br />
                実証の途中にあります。
              </p>
              <p className="text-gray-900">
                だからこそ、地域と一緒に育てていきたいと考えています。
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 sm:py-24 md:py-32 bg-white">
        <div className="max-w-4xl mx-auto px-5 sm:px-6 lg:px-8 text-center">
          <h2 className="mb-10 sm:mb-14">
            一緒に、地方の「行ける」を増やしませんか
          </h2>
          
          <div className="space-y-5 sm:space-y-6 text-gray-700 leading-relaxed mb-12 sm:mb-16 max-w-2xl mx-auto">
            <ul className="space-y-3 sm:space-y-4 text-left inline-block">
              <li className="flex items-start">
                <span className="mr-3 text-cyan-600 mt-1">•</span>
                <span>実証実験に興味のある自治体・企業の方</span>
              </li>
              <li className="flex items-start">
                <span className="mr-3 text-cyan-600 mt-1">•</span>
                <span>自転車の貸し出しや協力をご検討いただける方</span>
              </li>
              <li className="flex items-start">
                <span className="mr-3 text-cyan-600 mt-1">•</span>
                <span>プロジェクトに関わってみたい学生</span>
              </li>
            </ul>
          </div>

          <p className="text-gray-700 leading-loose mb-10 sm:mb-12">
            ぜひ、お気軽にご連絡ください。
          </p>

          <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 justify-center max-w-xl mx-auto">
            <button
              onClick={() => onNavigate('contact')}
              className="px-10 py-4 bg-cyan-600 text-white rounded-full hover:bg-cyan-700 transition-colors shadow-md"
            >
              お問い合わせ
            </button>
            <button
              onClick={() => onNavigate('company-info')}
              className="px-10 py-4 border-2 border-gray-300 text-gray-700 rounded-full hover:border-gray-400 transition-colors"
            >
              団体概要
            </button>
          </div>

          <p className="mt-10 sm:mt-12 text-gray-600 leading-loose">
            地方から、移動の未来を一緒につくりましょう。
          </p>
        </div>
      </section>
    </div>
  );
}